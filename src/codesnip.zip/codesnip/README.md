# codesnip
Le référentiel du projet codesnip, un outil pour afficher des extraits de code sur des pages web
